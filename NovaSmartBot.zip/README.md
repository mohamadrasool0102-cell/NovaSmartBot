# NovaSmartBot
