def reply(t):
    return t
